from django.db.models import fields
from testapp.models import Employee
from rest_framework.serializers import ModelSerializer

class  Employeeserializer(ModelSerializer):
    class Meta:
        model=Employee

        fields='__all__'
        

